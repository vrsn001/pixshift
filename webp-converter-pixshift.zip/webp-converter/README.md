# Pixshift — Convert Anything to WebP

A beautiful, fully browser-based media-to-WebP converter. Zero uploads, zero servers, complete privacy.

## Deploy to Vercel in 60 seconds

### Option 1 — Vercel CLI (recommended)
```bash
npm i -g vercel
cd pixshift
vercel
```
Follow the prompts. Done. Your site is live.

### Option 2 — Drag & Drop
1. Go to [vercel.com/new](https://vercel.com/new)
2. Drag this entire `pixshift` folder onto the page
3. Click Deploy

### Option 3 — GitHub
1. Push this folder to a GitHub repo
2. Connect the repo at [vercel.com/new](https://vercel.com/new)
3. Vercel auto-detects it as a static site — no config needed

## Project Structure
```
pixshift/
├── index.html     ← main page
├── style.css      ← all styles
├── app.js         ← converter logic
├── vercel.json    ← Vercel config
└── README.md
```

## Supported Formats
**Images:** JPG, JPEG, PNG, GIF, BMP, TIFF, AVIF, HEIC, SVG, WebP  
**Video:** MP4, MOV, AVI, WebM, MKV (extracts a frame)

## Features
- 10 resolution presets (Original → 4K UHD)
- Quality slider (10–100)
- Aspect ratio preserved
- Batch convert + ZIP download
- 100% browser-based via Canvas API
- No data ever leaves the user's device
